"""
Test Ctrl+C cancellation during AI execution.

This test verifies that Ctrl+C can interrupt AI responses.
"""
import asyncio
import signal
import time

import anyio
import pytest

from aish.cancellation import CancellationReason, CancellationToken


@pytest.mark.asyncio
@pytest.mark.timeout(10)
async def test_ctrl_c_cancel_during_llm_request():
    """Test that cancellation works during a simulated LLM request."""

    cancelled = False
    token = CancellationToken()

    async def simulated_llm_request():
        """Simulate a long-running LLM request that checks for cancellation."""
        nonlocal cancelled
        try:
            # Simulate a long operation with checkpoints
            for i in range(10):
                await anyio.sleep(0.5)  # 500ms per iteration
                # Check for cancellation
                if token.is_cancelled():
                    cancelled = True
                    raise anyio.get_cancelled_exc_class()
        except anyio.get_cancelled_exc_class():
            cancelled = True
            raise

    async def canceller():
        """Cancel the token after a delay."""
        await anyio.sleep(1.0)  # Wait 1 second before cancel
        token.cancel(CancellationReason.USER_INTERRUPT, "Test cancellation")

    async with anyio.create_task_group() as tg:
        tg.start_soon(simulated_llm_request)
        tg.start_soon(canceller)

    assert cancelled, "Operation should have been cancelled"


@pytest.mark.asyncio
@pytest.mark.timeout(10)
async def test_cancel_scope_in_llm():
    """Test that CancelScope properly cancels nested operations."""

    cancelled = False

    async def nested_operation():
        nonlocal cancelled
        try:
            with anyio.CancelScope() as scope:
                # Simulate LLM request
                await anyio.sleep(5.0)
                cancelled = False
        except anyio.get_cancelled_exc_class():
            cancelled = True
            raise

    async def cancel_after_delay():
        await anyio.sleep(1.0)
        # In a real scenario, this would be triggered by SIGINT
        pass

    # This test shows the pattern - in real code, we need to track
    # the CancelScope and cancel it from the signal handler
    await nested_operation()
    # For this test, we just verify the pattern works
    assert not cancelled  # Not cancelled in this simple test


@pytest.mark.asyncio
@pytest.mark.timeout(5)
async def test_token_cancel_checkpoints():
    """Test that cancellation checkpoints work correctly."""

    token = CancellationToken()
    checkpoints_reached = 0
    cancelled_at_checkpoint = -1

    async def operation_with_checkpoints():
        nonlocal checkpoints_reached, cancelled_at_checkpoint
        try:
            for i in range(10):
                checkpoints_reached += 1
                await anyio.sleep(0.2)  # 200ms per checkpoint

                # Check cancellation explicitly
                token.check_cancelled_sync()

                # Also check the token
                if token.is_cancelled():
                    cancelled_at_checkpoint = i
                    raise anyio.get_cancelled_exc_class()
        except anyio.get_cancelled_exc_class():
            raise

    async def cancel_early():
        await anyio.sleep(0.5)  # Cancel after ~2 checkpoints
        token.cancel(CancellationReason.USER_INTERRUPT, "Test")

    async with anyio.create_task_group() as tg:
        tg.start_soon(operation_with_checkpoints)
        tg.start_soon(cancel_early)

    assert checkpoints_reached > 1, "Should have reached some checkpoints"
    assert cancelled_at_checkpoint >= 0, "Should have been cancelled at a checkpoint"


if __name__ == "__main__":
    # Run a simple manual test
    async def manual_test():
        """Manual test for Ctrl+C cancellation."""
        token = CancellationToken()

        print("Starting manual test...")
        print("Press Ctrl+C to cancel (or wait 5 seconds)")

        async def long_operation():
            try:
                for i in range(50):
                    print(f"Step {i}/50")
                    await anyio.sleep(0.1)
                    if token.is_cancelled():
                        print("Cancellation detected!")
                        raise anyio.get_cancelled_exc_class()
            except anyio.get_cancelled_exc_class():
                print("Operation cancelled successfully")
                raise

        async def auto_cancel():
            await anyio.sleep(2.0)
            print("Auto-cancelling...")
            token.cancel(CancellationReason.USER_INTERRUPT, "Auto cancel")

        try:
            async with anyio.create_task_group() as tg:
                tg.start_soon(long_operation)
                tg.start_soon(auto_cancel)
        except anyio.get_cancelled_exc_class():
            print("Test completed - cancellation worked!")

    asyncio.run(manual_test())
