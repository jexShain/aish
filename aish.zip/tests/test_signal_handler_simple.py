#!/usr/bin/env python3
"""Test if signal handler works correctly."""
import signal
import sys
import time

# Test 1: Basic signal handler
print("Test 1: Basic signal handler")
handled = False

def handler(sig, frame):
    global handled
    handled = True
    print(f"Signal {sig} received")

original = signal.signal(signal.SIGINT, handler)
time.sleep(0.1)

import os
os.kill(os.getpid(), signal.SIGINT)
time.sleep(0.1)

signal.signal(signal.SIGINT, original)

if handled:
    print("✓ Basic signal handler works")
else:
    print("✗ Basic signal handler FAILED")

# Test 2: Check if our shell_pty signal handler works
print("\nTest 2: Check PTY signal handler")

try:
    from aish.shell_pty import PTYAIShell
    print("✓ PTYAIShell imported successfully")

    # Check if _sigint_handler exists
    if hasattr(PTYAIShell, '_sigint_handler'):
        print("✓ _sigint_handler method exists")
    else:
        print("✗ _sigint_handler method NOT found")

except Exception as e:
    print(f"✗ Failed to import PTYAIShell: {e}")

print("\nAll tests completed!")
