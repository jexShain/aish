"""Integration tests for PTY placeholder feature."""

from __future__ import annotations

import pytest

from aish.interruption import InterruptionManager, ShellState, PromptConfig
from aish.shell_pty_ui import PlaceholderManager


@pytest.fixture
def interruption_manager():
    """Create InterruptionManager for testing."""
    return InterruptionManager()


@pytest.fixture
def placeholder_manager(interruption_manager):
    """Create PlaceholderManager for testing."""
    return PlaceholderManager(interruption_manager)


def test_output_processor_shows_placeholder_after_prompt(
    placeholder_manager, interruption_manager
):
    """Test that OutputProcessor shows placeholder after bash prompt."""
    interruption_manager.set_state(ShellState.NORMAL)

    # Note: This test requires a mock PTYManager
    # For now, we'll skip full PTY integration
    # and test the logic separately

    # Simulate bash prompt output
    prompt_output = b"user@host:~$ "

    # Process should add placeholder
    # In this simplified test, we just verify placeholder manager logic
    placeholder_seq = placeholder_manager.show_placeholder()

    # Should contain the placeholder
    assert placeholder_seq != b""
    assert b"\x1b[90m" in placeholder_seq  # Gray color code


def test_input_router_clears_placeholder_on_input(
    placeholder_manager, interruption_manager
):
    """Test that InputRouter clears placeholder on character input."""
    interruption_manager.set_state(ShellState.NORMAL)

    # Note: This test requires mock PTYManager and AIHandler
    # For now, we test the state logic

    # Show placeholder first
    placeholder_manager.show_placeholder()
    assert placeholder_manager.is_visible() is True

    # InputRouter would call _clear_placeholder on input
    # We simulate that here
    clear_seq = placeholder_manager.clear_placeholder()
    assert clear_seq != b""
    assert placeholder_manager.is_visible() is False


def test_placeholder_state_transitions(
    placeholder_manager, interruption_manager
):
    """Test placeholder visibility across different shell states."""
    # NORMAL state should show placeholder
    interruption_manager.set_state(ShellState.NORMAL)
    text = placeholder_manager.get_placeholder_text()
    assert text is not None

    # Show placeholder
    seq = placeholder_manager.show_placeholder()
    assert seq != b""
    assert placeholder_manager.is_visible() is True

    # INPUTTING state should not show placeholder
    interruption_manager.set_state(ShellState.INPUTTING)
    text = placeholder_manager.get_placeholder_text()
    assert text is None

    # AI_THINKING state should not show placeholder
    interruption_manager.set_state(ShellState.AI_THINKING)
    text = placeholder_manager.get_placeholder_text()
    assert text is None


def test_placeholder_with_exit_pending_message(
    placeholder_manager, interruption_manager
):
    """Test placeholder shows exit confirmation message."""
    interruption_manager.set_state(ShellState.EXIT_PENDING)
    interruption_manager.show_prompt(
        PromptConfig(message="press Ctrl+C again to exit", window_seconds=2.0)
    )

    # Should get the exit message
    text = placeholder_manager.get_placeholder_text()
    assert text is not None
    assert "exit" in text.lower()


def test_placeholder_reset_for_new_line(
    placeholder_manager, interruption_manager
):
    """Test placeholder resets properly for new prompt line."""
    interruption_manager.set_state(ShellState.NORMAL)

    # Show placeholder
    placeholder_manager.show_placeholder()
    assert placeholder_manager.is_visible() is True

    # Simulate new line
    placeholder_manager.reset_for_new_line()
    assert placeholder_manager.is_visible() is False
    assert placeholder_manager.is_cleared() is False


def test_placeholder_mark_cleared(
    placeholder_manager, interruption_manager
):
    """Test placeholder mark_cleared functionality."""
    interruption_manager.set_state(ShellState.NORMAL)

    # Show placeholder
    placeholder_manager.show_placeholder()
    assert placeholder_manager.is_visible() is True

    # Mark as cleared (simulating user typing)
    placeholder_manager.mark_cleared()
    assert placeholder_manager.is_visible() is False
    assert placeholder_manager.is_cleared() is True


def test_placeholder_clear_when_not_visible(
    placeholder_manager, interruption_manager
):
    """Test clear_placeholder when placeholder is not visible."""
    interruption_manager.set_state(ShellState.NORMAL)

    # Don't show placeholder
    assert placeholder_manager.is_visible() is False

    # Clear should return empty bytes
    clear_seq = placeholder_manager.clear_placeholder()
    assert clear_seq == b""
