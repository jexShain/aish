#!/usr/bin/env python3
"""
Test Ctrl+C cancellation in PTY mode.

This test verifies that Ctrl+C works correctly when using PTY mode.
"""
import signal
import sys
import time

from aish.cancellation import CancellationReason, CancellationToken


def test_pty_signal_handler():
    """Test that the PTY signal handler cancels the token."""
    print("Testing PTY signal handler...")

    # Create a cancellation token
    token = CancellationToken()

    # Simulate the PTY signal handler
    def sigint_handler(signum, frame):
        """Handle SIGINT - cancel AI operations."""
        if token:
            token.cancel(
                CancellationReason.USER_INTERRUPT,
                "User pressed Ctrl+C"
            )

    # Set up signal handler
    original_handler = signal.signal(signal.SIGINT, sigint_handler)

    try:
        # Wait a bit
        time.sleep(0.5)

        # Check if not cancelled yet
        assert not token.is_cancelled(), "Token should not be cancelled yet"

        # Send SIGINT
        print("Sending SIGINT...")
        import os
        os.kill(os.getpid(), signal.SIGINT)

        # Wait for signal to be processed
        time.sleep(0.1)

        # Check if cancelled
        if token.is_cancelled():
            print("✓ Signal handler cancelled the token correctly")
            return True
        else:
            print("✗ Signal handler did NOT cancel the token")
            return False

    finally:
        # Restore original handler
        signal.signal(signal.SIGINT, original_handler)


def test_cancellation_in_operation():
    """Test that cancellation works during a simulated operation."""
    print("\nTesting cancellation during operation...")

    import threading

    cancelled = False
    token = CancellationToken()

    def long_operation():
        nonlocal cancelled
        try:
            for i in range(100):
                time.sleep(0.01)  # 10ms per iteration
                # Check cancellation
                if token.is_cancelled():
                    print(f"✓ Cancel detected at iteration {i}")
                    cancelled = True
                    return
        except Exception as e:
            print(f"Exception in operation: {e}")
            cancelled = True

    def cancel_after_delay():
        time.sleep(0.2)  # Cancel after 200ms
        token.cancel(CancellationReason.USER_INTERRUPT, "Test cancellation")

    # Start operation thread
    operation_thread = threading.Thread(target=long_operation)
    operation_thread.start()

    # Start cancel thread
    cancel_thread = threading.Thread(target=cancel_after_delay)
    cancel_thread.start()

    # Wait for both threads
    operation_thread.join(timeout=5)
    cancel_thread.join(timeout=5)

    if cancelled:
        print("✓ Operation was cancelled correctly")
        return True
    else:
        print("✗ Operation was NOT cancelled")
        return False


def main():
    print("=" * 60)
    print("PTY Mode Ctrl+C Cancellation Test")
    print("=" * 60)

    results = []

    # Test signal handler
    results.append(test_pty_signal_handler())

    # Test cancellation during operation
    results.append(test_cancellation_in_operation())

    print("\n" + "=" * 60)
    print("Summary:")
    print(f"  Passed: {sum(results)}/{len(results)}")
    print("=" * 60)

    if all(results):
        print("\n✓ All tests passed!")
        return 0
    else:
        print("\n✗ Some tests failed.")
        return 1


if __name__ == "__main__":
    sys.exit(main())
