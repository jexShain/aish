"""Tests for TUI module."""
