"""Tests for PlaceholderManager."""

from __future__ import annotations

import pytest

from aish.interruption import InterruptionManager, ShellState, PromptConfig
from aish.shell_pty_ui import PlaceholderManager


@pytest.fixture
def interruption_manager():
    """Create a InterruptionManager for testing."""
    return InterruptionManager()


@pytest.fixture
def placeholder_manager(interruption_manager):
    """Create a PlaceholderManager for testing."""
    return PlaceholderManager(interruption_manager)


def _reset_i18n_cache() -> None:
    """Reset i18n cache for consistent test results."""
    import aish.i18n as i18n

    i18n._UI_LOCALE = None  # type: ignore[attr-defined]
    i18n._MESSAGES = None  # type: ignore[attr-defined]
    i18n._MESSAGES_EN = None  # type: ignore[attr-defined]


class TestGetPlaceholderText:
    """Tests for get_placeholder_text method."""

    def test_normal_state_returns_ai_hint(self, placeholder_manager):
        """Normal state should return AI hint text."""
        placeholder_manager._interruption_manager.set_state(ShellState.NORMAL)
        result = placeholder_manager.get_placeholder_text()
        # Should return the AI hint (check if it's not None)
        assert result is not None
        assert "Ask AI" in result or "；" in result or ";" in result

    def test_exit_pending_state_returns_exit_message(self, placeholder_manager, interruption_manager):
        """EXIT_PENDING state should return exit confirmation message."""
        interruption_manager.set_state(ShellState.EXIT_PENDING)
        interruption_manager.show_prompt(
            PromptConfig(message="press Ctrl+C again to exit", window_seconds=2.0)
        )
        result = placeholder_manager.get_placeholder_text()
        assert result is not None
        assert "exit" in result.lower()

    def test_ai_thinking_state_returns_none(self, placeholder_manager, interruption_manager):
        """AI_THINKING state should not show placeholder."""
        interruption_manager.set_state(ShellState.AI_THINKING)
        result = placeholder_manager.get_placeholder_text()
        assert result is None

    def test_inputting_state_returns_none(self, placeholder_manager, interruption_manager):
        """INPUTTING state should not show placeholder."""
        interruption_manager.set_state(ShellState.INPUTTING)
        result = placeholder_manager.get_placeholder_text()
        assert result is None

    def test_sandbox_eval_state_returns_none(self, placeholder_manager, interruption_manager):
        """SANDBOX_EVAL state should not show placeholder."""
        interruption_manager.set_state(ShellState.SANDBOX_EVAL)
        result = placeholder_manager.get_placeholder_text()
        assert result is None

    def test_command_exec_state_returns_none(self, placeholder_manager, interruption_manager):
        """COMMAND_EXEC state should not show placeholder."""
        interruption_manager.set_state(ShellState.COMMAND_EXEC)
        result = placeholder_manager.get_placeholder_text()
        assert result is None

    def test_correct_pending_returns_none(self, placeholder_manager, interruption_manager):
        """CORRECT_PENDING state should return None (left prompt only)."""
        interruption_manager.set_state(ShellState.CORRECT_PENDING)
        result = placeholder_manager.get_placeholder_text()
        assert result is None


class TestShowPlaceholder:
    """Tests for show_placeholder method."""

    def test_show_placeholder_returns_ansi_sequence(self, placeholder_manager, interruption_manager):
        """show_placeholder should return ANSI escape sequence."""
        interruption_manager.set_state(ShellState.NORMAL)
        result = placeholder_manager.show_placeholder()
        assert isinstance(result, bytes)
        assert b"\x1b" in result  # ANSI escape
        assert b"\x1b[90m" in result or b"\x1b[0m" in result  # Color codes

    def test_show_placeholder_when_no_text_returns_empty(self, placeholder_manager, interruption_manager):
        """show_placeholder with None text should return empty bytes."""
        interruption_manager.set_state(ShellState.AI_THINKING)
        result = placeholder_manager.show_placeholder()
        assert result == b""

    def test_show_placeholder_sets_visible_flag(self, placeholder_manager, interruption_manager):
        """show_placeholder should set _placeholder_visible to True."""
        interruption_manager.set_state(ShellState.NORMAL)
        placeholder_manager.show_placeholder()
        assert placeholder_manager.is_visible() is True

    def test_show_placeholder_sets_cleared_flag_to_false(self, placeholder_manager, interruption_manager):
        """show_placeholder should set _cleared_for_current_line to False."""
        interruption_manager.set_state(ShellState.NORMAL)
        placeholder_manager._cleared_for_current_line = True
        placeholder_manager.show_placeholder()
        assert placeholder_manager.is_cleared() is False


class TestClearPlaceholder:
    """Tests for clear_placeholder method."""

    def test_clear_placeholder_returns_backspace_sequence(self, placeholder_manager):
        """clear_placeholder should return backspace sequence."""
        # First show a placeholder
        placeholder_manager._current_placeholder = "test"
        placeholder_manager._placeholder_visible = True

        result = placeholder_manager.clear_placeholder()
        assert isinstance(result, bytes)
        assert b"\b" in result  # Backspace

    def test_clear_placeholder_when_not_visible_returns_empty(self, placeholder_manager):
        """clear_placeholder when not visible should return empty bytes."""
        placeholder_manager._placeholder_visible = False
        result = placeholder_manager.clear_placeholder()
        assert result == b""

    def test_clear_placeholder_resets_visible_flag(self, placeholder_manager):
        """clear_placeholder should reset _placeholder_visible to False."""
        placeholder_manager._current_placeholder = "test"
        placeholder_manager._placeholder_visible = True

        placeholder_manager.clear_placeholder()

        assert placeholder_manager.is_visible() is False

    def test_clear_placeholder_handles_multibyte_chars(self, placeholder_manager):
        """clear_placeholder should handle multibyte characters correctly."""
        # Use a string with wide characters
        placeholder_manager._current_placeholder = "测试"
        placeholder_manager._placeholder_visible = True

        result = placeholder_manager.clear_placeholder()

        # Should have backspaces (wcwidth of "测试" is 4)
        assert len(result) > 0
        assert b"\b" in result


class TestStateManagement:
    """Tests for state management methods."""

    def test_mark_cleared_sets_cleared_flag(self, placeholder_manager):
        """mark_cleared should set _cleared_for_current_line to True."""
        placeholder_manager._placeholder_visible = True
        placeholder_manager.mark_cleared()
        assert placeholder_manager.is_cleared() is True
        assert placeholder_manager.is_visible() is False

    def test_reset_for_new_line_resets_all_state(self, placeholder_manager):
        """reset_for_new_line should reset all state flags."""
        placeholder_manager._placeholder_visible = True
        placeholder_manager._current_placeholder = "test"
        placeholder_manager._cleared_for_current_line = True

        placeholder_manager.reset_for_new_line()

        assert placeholder_manager.is_visible() is False
        assert placeholder_manager.is_cleared() is False
        assert placeholder_manager._current_placeholder is None

    def test_is_visible_returns_current_state(self, placeholder_manager):
        """is_visible should return current _placeholder_visible state."""
        assert placeholder_manager.is_visible() is False

        placeholder_manager._placeholder_visible = True
        assert placeholder_manager.is_visible() is True

    def test_is_cleared_returns_current_state(self, placeholder_manager):
        """is_cleared should return current _cleared_for_current_line state."""
        assert placeholder_manager.is_cleared() is False

        placeholder_manager._cleared_for_current_line = True
        assert placeholder_manager.is_cleared() is True
