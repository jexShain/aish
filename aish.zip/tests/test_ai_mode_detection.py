"""Tests for AI mode detection with zero-width character handling."""

import pytest

from aish.shell import AIShell
from aish.shell_enhanced.shell_completion import ModeAwareCompleter


class TestAIModeDetection:
    """Test AI mode detection handles zero-width and invisible characters."""

    # Zero-width and invisible characters that may be inserted by some IMEs
    ZWSP = "\u200b"  # Zero Width Space
    BOM = "\ufeff"  # BOM / Zero Width No-Break Space
    ZWNJ = "\u200c"  # Zero Width Non-Joiner
    ZWJ = "\u200d"  # Zero Width Joiner
    LRM = "\u200e"  # Left-to-Right Mark
    RLM = "\u200f"  # Right-to-Left Mark
    SOFT_HYPHEN = "\u00ad"  # Soft Hyphen
    MONGOLIAN_VS = "\u180e"  # Mongolian Vowel Separator
    ARABIC_LM = "\u061c"  # Arabic Letter Mark
    LRI = "\u2066"  # Left-to-Right Isolate
    RLI = "\u2067"  # Right-to-Left Isolate
    PDI = "\u2069"  # Pop Directional Isolate

    @pytest.fixture
    def shell(self):
        """Create a minimal AIShell instance for testing."""
        from unittest.mock import Mock

        shell = AIShell.__new__(AIShell)
        shell.logger = Mock()
        shell.SEMICOLON_MARKS = {";", "；"}
        shell._INVISIBLE_CHARS = frozenset(
            {
                "\u200b", "\u200c", "\u200d", "\u200e", "\u200f", "\u061c",
                "\ufeff", "\u00ad", "\u180e", "\u2060", "\u2061", "\u2062",
                "\u2063", "\u2064", "\u2066", "\u2067", "\u2068", "\u2069",
                "\u206a", "\u206b", "\u206c", "\u206d", "\u206e", "\u206f",
                "\u034f", "\u17b4", "\u17b5",
            }
        )
        return shell

    @pytest.mark.parametrize(
        "text,expected,description",
        [
            # Basic cases
            (";hello", True, "Latin semicolon"),
            ("；你好", True, "Chinese semicolon"),
            ("  ;hello", True, "Latin semicolon with leading spaces"),
            ("  ；你好", True, "Chinese semicolon with leading spaces"),
            # Zero-width character cases (the bug fix)
            ("\u200b；你好", True, "Chinese semicolon with ZWSP"),
            ("\ufeff；你好", True, "Chinese semicolon with BOM"),
            ("\u200c；你好", True, "Chinese semicolon with ZWNJ"),
            ("\u200d；你好", True, "Chinese semicolon with ZWJ"),
            ("\u200e；你好", True, "Chinese semicolon with LRM"),
            ("\u200f；你好", True, "Chinese semicolon with RLM"),
            ("\u00ad；你好", True, "Chinese semicolon with Soft Hyphen"),
            ("\u180e；你好", True, "Chinese semicolon with Mongolian VS"),
            ("\u061c；你好", True, "Chinese semicolon with Arabic LM"),
            ("\u2066；你好", True, "Chinese semicolon with LRI"),
            ("\u2067；你好", True, "Chinese semicolon with RLI"),
            ("\u2069；你好", True, "Chinese semicolon with PDI"),
            # Multiple invisible characters
            ("\u200b\u200c；你好", True, "Chinese semicolon with ZWSP+ZWNJ"),
            ("\ufeff\u200b；你好", True, "Chinese semicolon with BOM+ZWSP"),
            # Spaces combined with invisible characters
            ("  \u200b；你好", True, "Spaces + ZWSP + Chinese semicolon"),
            # Negative cases (should NOT be detected as AI mode)
            ("hello", False, "No semicolon"),
            ("", False, "Empty string"),
            ("  ", False, "Only spaces"),
            ("\u200bhello", False, "ZWSP without semicolon"),
            ("\ufeffhello", False, "BOM without semicolon"),
            # Latin semicolon with invisible characters
            ("\u200b;hello", True, "ZWSP + Latin semicolon"),
            ("\ufeff;hello", True, "BOM + Latin semicolon"),
        ],
    )
    def test_starts_with_question_mark(self, shell, text, expected, description):
        """Test that starts_with_question_mark correctly handles invisible chars."""
        # Simulate the actual call flow: strip() is called before the method
        stripped_text = text.strip()
        result = shell.starts_with_question_mark(stripped_text)
        assert result == expected, f"Failed for: {description}"

    @pytest.mark.parametrize(
        "text,expected,description",
        [
            # Basic cases
            (";hello", "hello", "Latin semicolon"),
            ("；你好", "你好", "Chinese semicolon"),
            # Zero-width character cases
            ("\u200b；你好", "你好", "ZWSP + Chinese semicolon"),
            ("\ufeff；你好", "你好", "BOM + Chinese semicolon"),
            ("\u200b\u200c；你好", "你好", "Multiple invisible + Chinese semicolon"),
            # No semicolon cases
            ("hello", "hello", "No semicolon"),
            ("\u200bhello", "hello", "ZWSP without semicolon"),
        ],
    )
    def test_strip_leading_question_mark(self, shell, text, expected, description):
        """Test that strip_leading_question_mark correctly handles invisible chars."""
        result = shell.strip_leading_question_mark(text)
        assert result == expected, f"Failed for: {description}"


class TestModeAwareCompleterAIMode:
    """Test ModeAwareCompleter._is_ai_mode with invisible characters."""

    @pytest.fixture
    def completer(self):
        """Create a minimal ModeAwareCompleter for testing."""
        from unittest.mock import Mock

        ai_completer = Mock()
        shell_completer = Mock()
        ai_prefix_marks = {";", "；"}
        return ModeAwareCompleter(ai_completer, shell_completer, ai_prefix_marks)

    @pytest.mark.parametrize(
        "text,expected,description",
        [
            # Basic cases
            (";hello", True, "Latin semicolon"),
            ("；你好", True, "Chinese semicolon"),
            # Zero-width character cases
            ("\u200b；你好", True, "ZWSP + Chinese semicolon"),
            ("\ufeff；你好", True, "BOM + Chinese semicolon"),
            ("\u2066；你好", True, "LRI + Chinese semicolon"),
            # Negative cases
            ("hello", False, "No semicolon"),
            ("\u200bhello", False, "ZWSP without semicolon"),
        ],
    )
    def test_is_ai_mode(self, completer, text, expected, description):
        """Test that _is_ai_mode correctly handles invisible chars."""
        from prompt_toolkit.document import Document

        doc = Document(text=text)
        result = completer._is_ai_mode(doc)
        assert result == expected, f"Failed for: {description}"
