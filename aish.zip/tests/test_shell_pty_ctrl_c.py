"""Tests for Ctrl+C handling in shell_pty mode."""
import pytest
import anyio

from aish.cancellation import CancellationToken, CancellationReason


def test_on_interrupt_requested_cancels_token():
    """Test that _on_interrupt_requested cancels the cancellation token."""
    token = CancellationToken()
    assert not token.is_cancelled()

    # Simulate what _on_interrupt_requested does
    token.cancel(CancellationReason.USER_INTERRUPT, "User pressed Ctrl+C")
    assert token.is_cancelled()
    assert token.get_cancellation_reason() == CancellationReason.USER_INTERRUPT


def test_cancel_token_child_propagation():
    """Test that child token inherits parent cancellation."""
    parent = CancellationToken()
    child = parent.create_child_token()

    assert not child.is_cancelled()

    parent.cancel(CancellationReason.USER_INTERRUPT, "Parent cancelled")
    assert child.is_cancelled()
    assert child.get_cancellation_reason() == CancellationReason.PARENT_CANCELLED


def test_cancel_token_idempotent():
    """Test that cancelling an already cancelled token is a no-op."""
    token = CancellationToken()
    token.cancel(CancellationReason.USER_INTERRUPT, "First")
    assert token.is_cancelled()

    # Second cancel should not raise and reason should remain the first one
    token.cancel(CancellationReason.TIMEOUT, "Second")
    assert token.get_cancellation_reason() == CancellationReason.USER_INTERRUPT


@pytest.mark.anyio
async def test_token_cancel_scopes_via_cancel():
    """Test that cancelling a token cancels all registered scopes."""
    token = CancellationToken()
    scope_was_cancelled = False

    async def operation():
        nonlocal scope_was_cancelled
        with anyio.CancelScope() as scope:
            token._register_scope(scope)
            try:
                await anyio.sleep(10)  # Long operation
            finally:
                token._unregister_scope(scope)
        # If we reach here, the scope caught the cancellation
        scope_was_cancelled = scope.cancelled_caught

    async def send_signal():
        await anyio.sleep(0.2)
        token.cancel(CancellationReason.USER_INTERRUPT, "SIGINT")

    async with anyio.create_task_group() as tg:
        tg.start_soon(operation)
        tg.start_soon(send_signal)

    assert scope_was_cancelled, "CancelScope should have caught cancellation"


@pytest.mark.anyio
async def test_token_open_cancel_scope():
    """Test that open_cancel_scope creates a scope tied to the token."""
    token = CancellationToken()
    scope_was_cancelled = False

    async def operation():
        nonlocal scope_was_cancelled
        with token.open_cancel_scope() as scope:
            await anyio.sleep(10)  # Long operation
        # If we reach here, the scope caught the cancellation
        scope_was_cancelled = scope.cancelled_caught

    async def send_signal():
        await anyio.sleep(0.2)
        token.cancel(CancellationReason.USER_INTERRUPT, "SIGINT")

    async with anyio.create_task_group() as tg:
        tg.start_soon(operation)
        tg.start_soon(send_signal)

    assert scope_was_cancelled, "CancelScope should have caught cancellation"


@pytest.mark.anyio
async def test_interruption_manager_trigger_interrupt():
    """Test that InterruptionManager trigger_interrupt calls the callback."""
    from aish.interruption import InterruptionManager

    manager = InterruptionManager()
    callback_called = False

    def on_interrupt():
        nonlocal callback_called
        callback_called = True

    manager.set_interrupt_callback(on_interrupt)
    assert not callback_called

    manager.trigger_interrupt()
    assert callback_called


@pytest.mark.anyio
async def test_interruption_manager_state_transitions():
    """Test that InterruptionManager state transitions work correctly."""
    from aish.interruption import InterruptionManager, ShellState

    manager = InterruptionManager()

    # Initial state
    assert manager.state == ShellState.NORMAL

    # Set to AI_THINKING
    manager.set_state(ShellState.AI_THINKING)
    assert manager.state == ShellState.AI_THINKING

    # Verify last AI state is saved
    assert manager.get_last_ai_state() == ShellState.AI_THINKING

    # Return to NORMAL
    manager.set_state(ShellState.NORMAL)
    assert manager.state == ShellState.NORMAL

    # Last AI state should be preserved
    assert manager.get_last_ai_state() == ShellState.AI_THINKING

    # Clear last AI state
    manager.clear_last_ai_state()
    assert manager.get_last_ai_state() is None
