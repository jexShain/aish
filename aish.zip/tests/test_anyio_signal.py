#!/usr/bin/env python3
"""
Test Ctrl+C cancellation in PTY mode with anyio.run()

This test verifies that Ctrl+C works correctly when AI operations
are run through anyio.run() in PTY mode.
"""
import signal
import sys
import time

import anyio


def test_anyio_run_with_signal():
    """Test that anyio.run() can handle SIGINT."""
    print("Testing anyio.run() with signal handling...")

    cancelled = False
    signal_received = False

    async def operation():
        nonlocal cancelled, signal_received
        # Use signal receiver inside anyio.run()
        with anyio.open_signal_receiver(signal.SIGINT) as sigs:
            async def signal_handler():
                nonlocal signal_received, cancelled
                async for _ in sigs:
                    print("Signal received, cancelling...")
                    signal_received = True
                    cancelled = True
                    print("Setting cancelled flag and raising exception...")
                    raise anyio.get_cancelled_exc_class()

            async with anyio.create_task_group() as tg:
                tg.start_soon(signal_handler)

                # Simulate a long operation
                for i in range(100):
                    await anyio.sleep(0.05)  # 50ms per iteration
                    print(f"Iteration {i}/100")
                    if i >= 10:  # Safety limit
                        break

    def send_signal():
        time.sleep(0.3)  # Send signal after 300ms
        print("Sending SIGINT...")
        import os
        os.kill(os.getpid(), signal.SIGINT)

    import threading
    signal_thread = threading.Thread(target=send_signal)
    signal_thread.start()

    try:
        anyio.run(operation)
    except anyio.get_cancelled_exc_class:
        print("Cancellation exception caught in main")

    signal_thread.join(timeout=5)

    print(f"signal_received={signal_received}, cancelled={cancelled}")

    if cancelled:
        print("✓ anyio.run() correctly handled signal")
        return True
    else:
        print("✗ anyio.run() did NOT handle signal correctly")
        return False


def main():
    print("=" * 60)
    print("PTY Mode anyio.run() Signal Test")
    print("=" * 60)

    result = test_anyio_run_with_signal()

    print("\n" + "=" * 60)
    if result:
        print("✓ Test passed!")
        return 0
    else:
        print("✗ Test failed.")
        return 1


if __name__ == "__main__":
    sys.exit(main())
