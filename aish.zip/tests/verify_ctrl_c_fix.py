#!/usr/bin/env python3
"""
Verify Ctrl+C cancellation fix.

This script tests that Ctrl+C works correctly during:
1. AI streaming response
2. Tool execution (bash commands)
"""
import asyncio
import signal
import sys
import time

import anyio

from aish.cancellation import CancellationReason, CancellationToken


async def test_streaming_cancel():
    """Test cancellation during streaming response simulation."""
    print("Testing streaming cancellation...")

    cancelled = False
    token = CancellationToken()

    async def simulate_streaming():
        nonlocal cancelled
        try:
            for i in range(100):
                await anyio.sleep(0.1)
                # Check cancellation at each chunk
                if token.is_cancelled():
                    print(f"✓ Cancel detected at chunk {i}")
                    cancelled = True
                    raise anyio.get_cancelled_exc_class()
        except anyio.get_cancelled_exc_class():
            cancelled = True
            raise

    async def cancel_after_delay():
        await anyio.sleep(0.5)  # Cancel after 500ms
        token.cancel(CancellationReason.USER_INTERRUPT, "Test cancellation")

    try:
        async with anyio.create_task_group() as tg:
            tg.start_soon(simulate_streaming)
            tg.start_soon(cancel_after_delay)
    except anyio.get_cancelled_exc_class():
        pass

    if cancelled:
        print("✓ Streaming cancellation works correctly")
    else:
        print("✗ Streaming cancellation FAILED")
        return False

    return True


async def test_bash_cancel():
    """Test cancellation during bash command simulation."""
    print("\nTesting bash command cancellation...")

    cancelled = False
    token = CancellationToken()

    # Create a cancel event adapter
    class CancelEventAdapter:
        def __init__(self, cancellation_token):
            self._token = cancellation_token

        def is_set(self) -> bool:
            return self._token.is_cancelled() if self._token else False

    async def simulate_bash_command():
        nonlocal cancelled
        try:
            # Simulate a long-running command
            for i in range(10):
                await anyio.sleep(0.5)
                # Check cancellation
                cancel_event = CancelEventAdapter(token)
                if cancel_event.is_set():
                    print(f"✓ Cancel detected at step {i}")
                    cancelled = True
                    raise anyio.get_cancelled_exc_class()
        except anyio.get_cancelled_exc_class():
            cancelled = True
            raise

    async def cancel_after_delay():
        await anyio.sleep(1.0)  # Cancel after 1 second
        token.cancel(CancellationReason.USER_INTERRUPT, "Test cancellation")

    try:
        async with anyio.create_task_group() as tg:
            tg.start_soon(simulate_bash_command)
            tg.start_soon(cancel_after_delay)
    except anyio.get_cancelled_exc_class():
        pass

    if cancelled:
        print("✓ Bash command cancellation works correctly")
    else:
        print("✗ Bash command cancellation FAILED")
        return False

    return True


async def main():
    print("=" * 60)
    print("Ctrl+C Cancellation Fix Verification")
    print("=" * 60)

    results = []

    # Test streaming cancellation
    results.append(await test_streaming_cancel())

    # Test bash command cancellation
    results.append(await test_bash_cancel())

    print("\n" + "=" * 60)
    print("Summary:")
    print(f"  Passed: {sum(results)}/{len(results)}")
    print("=" * 60)

    if all(results):
        print("\n✓ All tests passed! Ctrl+C cancellation is working correctly.")
        return 0
    else:
        print("\n✗ Some tests failed. Please check the implementation.")
        return 1


if __name__ == "__main__":
    exit_code = asyncio.run(main())
    sys.exit(exit_code)
