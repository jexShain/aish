"""Tests for PTYUserInteraction."""

import pytest
from aish.shell_pty_ui import PTYUserInteraction


def test_get_confirmation_returns_true_for_y(monkeypatch):
    """Test that 'y' returns True."""
    import termios
    import tty

    ui = PTYUserInteraction()

    # Track calls
    call_log = []

    # Mock stdin to return 'y'
    def mock_read(size):
        call_log.append(f"read({size})")
        return 'y'

    # Mock termios functions
    def mock_tcgetattr(fd):
        call_log.append(f"tcgetattr({fd})")
        return [0, 0, 0, 0, 0, 0]

    def mock_tcsetattr(fd, when, attrs):
        call_log.append(f"tcsetattr({fd}, {when}, {attrs})")

    def mock_setraw(fd):
        call_log.append(f"setraw({fd})")

    monkeypatch.setattr("sys.stdin.read", mock_read)
    monkeypatch.setattr("sys.stdin.fileno", lambda: 0)
    monkeypatch.setattr(termios, "tcgetattr", mock_tcgetattr)
    monkeypatch.setattr(termios, "tcsetattr", mock_tcsetattr)
    monkeypatch.setattr(termios, "TCSADRAIN", 0)
    monkeypatch.setattr(tty, "setraw", mock_setraw)

    result = ui.get_confirmation()

    print(f"Call log: {call_log}")
    print(f"Result: {result}")
    assert result is True


def test_get_confirmation_returns_false_for_n(monkeypatch):
    """Test that 'n' returns False."""
    import termios
    import tty

    ui = PTYUserInteraction()

    inputs = iter(['n'])
    monkeypatch.setattr("sys.stdin.read", lambda size: next(inputs))
    monkeypatch.setattr("sys.stdin.fileno", lambda: 0)
    monkeypatch.setattr(termios, "tcgetattr", lambda fd: [0, 0, 0, 0, 0, 0])
    monkeypatch.setattr(termios, "tcsetattr", lambda fd, when, attrs: None)
    monkeypatch.setattr(termios, "TCSADRAIN", 0)
    monkeypatch.setattr(tty, "setraw", lambda fd: None)

    result = ui.get_confirmation()
    assert result is False


def test_get_confirmation_returns_false_for_other(monkeypatch):
    """Test that other keys return False."""
    import termios
    import tty

    ui = PTYUserInteraction()

    inputs = iter(['x'])
    monkeypatch.setattr("sys.stdin.read", lambda size: next(inputs))
    monkeypatch.setattr("sys.stdin.fileno", lambda: 0)
    monkeypatch.setattr(termios, "tcgetattr", lambda fd: [0, 0, 0, 0, 0, 0])
    monkeypatch.setattr(termios, "tcsetattr", lambda fd, when, attrs: None)
    monkeypatch.setattr(termios, "TCSADRAIN", 0)
    monkeypatch.setattr(tty, "setraw", lambda fd: None)

    result = ui.get_confirmation()
    assert result is False


def test_request_choice_valid_option(monkeypatch):
    """Test requesting a choice with valid selection."""
    import termios
    import tty

    ui = PTYUserInteraction()
    options = [
        {"id": "opt1", "label": "Option 1"},
        {"id": "opt2", "label": "Option 2"},
    ]

    # Mock: user types "1" then Enter
    inputs = iter(['1', '\n'])
    call_count = [0]

    def mock_read(size):
        call_count[0] += 1
        return next(inputs)

    monkeypatch.setattr("sys.stdin.read", mock_read)
    monkeypatch.setattr("sys.stdin.fileno", lambda: 0)
    monkeypatch.setattr(termios, "tcgetattr", lambda fd: [0, 0, 0, 0, 0, 0])
    monkeypatch.setattr(termios, "tcsetattr", lambda fd, when, attrs: None)
    monkeypatch.setattr(termios, "TCSADRAIN", 0)
    monkeypatch.setattr(tty, "setraw", lambda fd: None)

    result = ui.request_choice("Select:", options)
    assert result == ("opt1", "")


def test_request_choice_custom_input(monkeypatch):
    """Test requesting custom input."""
    import termios
    import tty
    import builtins

    ui = PTYUserInteraction()
    options = [{"id": "opt1", "label": "Option 1"}]

    # Mock: user types "0", then custom input
    read_inputs = iter(['0', '\n', 'custom value'])
    input_values = iter(['custom value'])

    def mock_read(size):
        return next(read_inputs)

    def mock_input(prompt=""):
        return next(input_values)

    monkeypatch.setattr("sys.stdin.read", mock_read)
    monkeypatch.setattr("sys.stdin.fileno", lambda: 0)
    monkeypatch.setattr(termios, "tcgetattr", lambda fd: [0, 0, 0, 0, 0, 0])
    monkeypatch.setattr(termios, "tcsetattr", lambda fd, when, attrs: None)
    monkeypatch.setattr(termios, "TCSADRAIN", 0)
    monkeypatch.setattr(tty, "setraw", lambda fd: None)
    monkeypatch.setattr(builtins, "input", mock_input)

    result = ui.request_choice("Select:", options, allow_custom_input=True)
    assert result == (None, "custom value")
