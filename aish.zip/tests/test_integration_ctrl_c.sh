#!/bin/bash
# Integration test for Ctrl+C cancellation
# This test verifies that Ctrl+C works correctly during AI execution

set -e

echo "=== Integration Test for Ctrl+C Cancellation ==="
echo ""
echo "This test will:"
echo "1. Start aish"
echo "2. Send a long-running AI request"
echo "3. Send SIGINT (Ctrl+C)"
echo "4. Verify cancellation works"
echo ""

# Create a test script that simulates Ctrl+C
cat > /tmp/test_ctrl_c.py << 'EOF'
import asyncio
import signal
import sys

async def main():
    # Simulate starting aish and sending Ctrl+C
    print("Starting aish...")

    # Send AI request
    print("? explain quantum physics in detail")

    # Wait a bit for AI to start processing
    await asyncio.sleep(2)

    # Send Ctrl+C
    print("Sending SIGINT...")
    import os
    os.kill(os.getpid(), signal.SIGINT)

    await asyncio.sleep(1)
    print("Test completed")

if __name__ == "__main__":
    asyncio.run(main())
EOF

python /tmp/test_ctrl_c.py

echo ""
echo "=== Integration Test Complete ==="
