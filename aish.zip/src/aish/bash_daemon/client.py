"""Simple Unix Socket client for bash daemon.

Based on pyxtermjs approach: simple polling and callbacks.
"""

from __future__ import annotations

import json
import os
import queue
import select
import socket
import struct
import threading
import time
from typing import Callable, Optional


class SimpleBashClient:
    """Simple synchronous client for bash daemon.

    Usage:
        client = SimpleBashClient()
        client.connect()

        # With callback
        client.subscribe(lambda data: print(data, end=''))
        client.send("ls\n")
        time.sleep(1)

        # Or polling
        client.send("echo hello\n")
        output = client.recv(timeout=1.0)
        print(output)

        client.close()
    """

    def __init__(
        self,
        socket_path: Optional[str] = None,
        rows: int = 24,
        cols: int = 80,
        cwd: Optional[str] = None,
    ):
        # Default socket path
        runtime_dir = os.environ.get("XDG_RUNTIME_DIR", f"/run/user/{os.getuid()}")
        if not os.path.exists(runtime_dir):
            runtime_dir = f"/tmp/aish-{os.getuid()}"
        self.socket_path = socket_path or os.path.join(runtime_dir, "aish", "bashd.sock")

        self._rows = rows
        self._cols = cols
        self._cwd = cwd or os.getcwd()

        self._sock: Optional[socket.socket] = None
        self.session_id: Optional[str] = None
        self._connected = False
        self._output_queue: queue.Queue = queue.Queue()
        self._callback: Optional[Callable[[bytes], None]] = None
        self._status_callback: Optional[Callable[[str, int], None]] = None
        self._reader_thread: Optional[threading.Thread] = None
        self._reading = False

        # Current state
        self._current_cwd = self._cwd
        self._last_exit_code = 0
        self._last_seq = -1  # Command sequence number for status updates

    def connect(self, cwd: Optional[str] = None) -> str:
        """Connect to daemon and create a session."""
        if self._connected:
            return self.session_id

        try:
            self._sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
            self._sock.connect(self.socket_path)
            self._sock.setblocking(True)

            # Use instance attributes or override with cwd parameter
            actual_cwd = cwd or self._cwd or os.getcwd()

            # Send session create request
            self._write_message({
                "type": "session_create",
                "data": {"rows": self._rows, "cols": self._cols, "cwd": actual_cwd}
            })

            # Wait for response
            response = self._read_message()
            if response is None or response.get("type") != "session_created":
                raise ConnectionError("Failed to create session")

            self.session_id = response.get("session_id")
            self._connected = True

            return self.session_id

        except socket.error as e:
            if self._sock:
                self._sock.close()
                self._sock = None
            raise ConnectionError(f"Failed to connect: {e}")

    def send(self, data: bytes) -> int:
        """Send input to bash."""
        if not self._connected:
            raise ConnectionError("Not connected")

        self._write_message({
            "type": "input",
            "session_id": self.session_id,
            "data": {"bytes": data.hex()}
        })
        return len(data)

    def recv(self, timeout: float = 0.5) -> Optional[bytes]:
        """Receive output from bash (polling mode)."""
        if not self._connected:
            return None

        # Auto-start reader thread if not already running
        if not self._reading:
            self._reading = True
            self._reader_thread = threading.Thread(target=self._read_loop, daemon=True)
            self._reader_thread.start()

        try:
            return self._output_queue.get(timeout=timeout)
        except queue.Empty:
            return None

    def recv_all(self, idle_timeout: float = 0.3) -> bytes:
        """Receive all available output until idle."""
        outputs = []
        last_data = time.time()

        while True:
            try:
                data = self._output_queue.get(timeout=0.1)
                outputs.append(data)
                last_data = time.time()
            except queue.Empty:
                if outputs and time.time() - last_data > idle_timeout:
                    break
                elif not outputs and time.time() - last_data > idle_timeout * 2:
                    break

        return b"".join(outputs)

    def subscribe(self, callback: Callable[[bytes], None]) -> None:
        """Subscribe to output with callback."""
        self._callback = callback

        if not self._reading:
            self._reading = True
            self._reader_thread = threading.Thread(target=self._read_loop, daemon=True)
            self._reader_thread.start()
            # Give thread time to start
            import time
            time.sleep(0.01)

    def subscribe_status(self, callback: Callable[[str, int], None]) -> None:
        """Subscribe to status updates (cwd, exit_code)."""
        self._status_callback = callback

        if not self._reading:
            self._reading = True
            self._reader_thread = threading.Thread(target=self._read_loop, daemon=True)
            self._reader_thread.start()
            # Give thread time to start
            import time
            time.sleep(0.01)

    def unsubscribe(self) -> None:
        """Stop callback subscription."""
        self._reading = False
        self._callback = None
        self._status_callback = None

    def clear_output_queue(self) -> None:
        """Clear any pending output in the queue.

        This should be called after finishing an interactive command
        to prevent old output from appearing in the next command.
        """
        while not self._output_queue.empty():
            try:
                self._output_queue.get_nowait()
            except queue.Empty:
                break

    @property
    def current_cwd(self) -> str:
        """Get current working directory."""
        return self._current_cwd

    @property
    def last_exit_code(self) -> int:
        """Get last command exit code."""
        return self._last_exit_code

    def get_status(self) -> dict:
        """Get current status (cwd, exit_code)."""
        return {
            'cwd': self._current_cwd,
            'exit_code': self._last_exit_code
        }

    def resize(self, rows: int, cols: int) -> None:
        """Resize terminal."""
        if not self._connected:
            return

        self._write_message({
            "type": "resize",
            "session_id": self.session_id,
            "data": {"rows": rows, "cols": cols}
        })

    def close(self) -> None:
        """Close the session."""
        self._reading = False

        if self._connected and self._sock:
            try:
                self._write_message({
                    "type": "session_close",
                    "session_id": self.session_id
                })
            except Exception:
                pass

        if self._sock:
            try:
                self._sock.close()
            except Exception:
                pass

        self._sock = None
        self._connected = False
        self.session_id = None

    @property
    def is_connected(self) -> bool:
        return self._connected

    def _read_loop(self) -> None:
        """Background thread to read messages."""
        while self._reading and self._connected:
            try:
                # Use select for timeout
                ready, _, _ = select.select([self._sock], [], [], 0.1)
                if not ready:
                    continue

                msg = self._read_message()
                if msg is None:
                    break

                msg_type = msg.get("type")

                if msg_type == "output":
                    hex_bytes = msg.get("data", {}).get("bytes", "")
                    if hex_bytes:
                        data = bytes.fromhex(hex_bytes)
                        self._output_queue.put(data)
                        if self._callback:
                            try:
                                self._callback(data)
                            except Exception:
                                pass

                elif msg_type == "status":
                    # Handle status update (cwd, exit code, seq)
                    data = msg.get("data", {})
                    if data.get("cwd"):
                        self._current_cwd = data["cwd"]
                    exit_code = data.get("exit")
                    if exit_code is not None:
                        self._last_exit_code = exit_code
                    seq = data.get("seq", -1)
                    if seq is not None:
                        self._last_seq = seq
                    if self._status_callback:
                        try:
                            self._status_callback(self._current_cwd, self._last_exit_code, self._last_seq)
                        except Exception:
                            pass

                elif msg_type == "session_closed":
                    self._connected = False
                    break

            except (ConnectionError, OSError):
                break

    def _read_message(self) -> Optional[dict]:
        """Read a JSON message with 4-byte length prefix."""
        try:
            length_data = self._sock.recv(4)
            if len(length_data) < 4:
                return None

            length = struct.unpack(">I", length_data)[0]
            if length == 0 or length > 1024 * 1024:
                print(f"[DEBUG] Invalid length: {length}", file=sys.stderr)
                return None

            data = b""
            while len(data) < length:
                chunk = self._sock.recv(length - len(data))
                if not chunk:
                    print(f"[DEBUG] Connection closed, got {len(data)}/{length} bytes", file=sys.stderr)
                    return None
                data += chunk

            return json.loads(data.decode("utf-8"))

        except (ConnectionError, json.JSONDecodeError, struct.error, UnicodeDecodeError) as e:
            import sys
            print(f"[DEBUG] _read_message error: {type(e).__name__}: {e}", file=sys.stderr)
            print(f"[DEBUG] length_data: {length_data.hex() if length_data else 'None'}", file=sys.stderr)
            if 'length' in dir():
                print(f"[DEBUG] expected length: {length}, got: {len(data)}", file=sys.stderr)
            return None

    def _write_message(self, msg: dict) -> None:
        """Write a JSON message with 4-byte length prefix."""
        data = json.dumps(msg, separators=(",", ":")).encode("utf-8")
        length = struct.pack(">I", len(data))
        self._sock.sendall(length + data)

    def __enter__(self) -> "SimpleBashClient":
        self.connect()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        self.close()
