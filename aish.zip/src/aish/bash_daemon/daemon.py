"""Daemon management for bash_daemon.

Provides functions to start, stop, and check the daemon process.
The daemon is started on-demand when aish starts.
"""

from __future__ import annotations

import os
import signal
import subprocess
import sys
import time
from pathlib import Path
from typing import Optional

# Default socket path
RUNTIME_DIR = os.environ.get("XDG_RUNTIME_DIR", f"/run/user/{os.getuid()}")
if not os.path.exists(RUNTIME_DIR):
    RUNTIME_DIR = f"/tmp/aish-{os.getuid()}"
    os.makedirs(RUNTIME_DIR, mode=0o700, exist_ok=True)
DEFAULT_SOCKET_PATH = os.path.join(RUNTIME_DIR, "aish", "bashd.sock")


def is_daemon_running(socket_path: Optional[str] = None) -> bool:
    """Check if the bash_daemon is running.

    Args:
        socket_path: Path to the Unix socket

    Returns:
        True if daemon is running and accepting connections
    """
    socket_path = socket_path or DEFAULT_SOCKET_PATH

    if not os.path.exists(socket_path):
        return False

    # Try to connect to verify it's actually running
    import socket

    try:
        sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        sock.settimeout(1.0)
        sock.connect(socket_path)
        sock.close()
        return True
    except (socket.error, OSError):
        # Socket exists but daemon not running, clean up
        try:
            os.unlink(socket_path)
        except OSError:
            pass
        return False


def get_daemon_pid() -> Optional[int]:
    """Get the daemon's PID if running.

    Returns:
        PID or None if not running
    """
    pid_file = _get_pid_file()
    if not os.path.exists(pid_file):
        return None

    try:
        with open(pid_file, "r") as f:
            pid = int(f.read().strip())

        # Check if process exists
        os.kill(pid, 0)
        return pid
    except (ValueError, OSError):
        # Invalid PID or process not running
        try:
            os.unlink(pid_file)
        except OSError:
            pass
        return None


def start_daemon(
    socket_path: Optional[str] = None,
    foreground: bool = False,
    debug: bool = False,
) -> bool:
    """Start the bash_daemon.

    Args:
        socket_path: Path to the Unix socket
        foreground: Run in foreground (for debugging)
        debug: Enable debug logging

    Returns:
        True if daemon started successfully
    """
    socket_path = socket_path or DEFAULT_SOCKET_PATH

    # Check if already running
    if is_daemon_running(socket_path):
        return True

    # Build command
    cmd = [sys.executable, "-m", "aish.bash_daemon.server"]

    if debug:
        cmd.append("--debug")

    if foreground:
        # Run in foreground
        from .server import SimpleBashDaemon
        import logging

        logging.basicConfig(
            format="%(asctime)s [bashd] %(message)s",
            level=logging.DEBUG if debug else logging.INFO,
        )

        daemon = SimpleBashDaemon(socket_path)
        daemon.start()

        def handle_signal(sig, frame):
            daemon.stop()
            sys.exit(0)

        signal.signal(signal.SIGTERM, handle_signal)
        signal.signal(signal.SIGINT, handle_signal)

        while daemon.running:
            time.sleep(1)
        return True

    # Fork to background
    pid = os.fork()
    if pid > 0:
        # Parent: wait for daemon to start
        for _ in range(50):  # 5 seconds max
            time.sleep(0.1)
            if is_daemon_running(socket_path):
                return True
        return False

    # Child: become daemon
    os.setsid()

    # Redirect standard file descriptors
    null_fd = os.open(os.devnull, os.O_RDWR)
    os.dup2(null_fd, 0)  # stdin
    os.dup2(null_fd, 1)  # stdout
    os.dup2(null_fd, 2)  # stderr
    os.close(null_fd)

    # Write PID file
    pid_file = _get_pid_file()
    try:
        os.makedirs(os.path.dirname(pid_file), mode=0o700, exist_ok=True)
        with open(pid_file, "w") as f:
            f.write(str(os.getpid()))
    except OSError:
        pass

    # Run daemon
    from .server import SimpleBashDaemon
    import logging

    logging.basicConfig(
        format="%(asctime)s [bashd] %(message)s",
        level=logging.DEBUG if debug else logging.INFO,
    )

    daemon = SimpleBashDaemon(socket_path)

    def handle_signal(signum, frame):
        daemon.stop()

    signal.signal(signal.SIGTERM, handle_signal)
    signal.signal(signal.SIGINT, handle_signal)

    try:
        daemon.start()
        while daemon.running:
            time.sleep(1)
    finally:
        # Clean up PID file
        try:
            os.unlink(pid_file)
        except OSError:
            pass

    return True


def stop_daemon(socket_path: Optional[str] = None) -> bool:
    """Stop the bash_daemon.

    Args:
        socket_path: Path to the Unix socket

    Returns:
        True if daemon stopped successfully
    """
    socket_path = socket_path or DEFAULT_SOCKET_PATH

    pid = get_daemon_pid()
    if pid is None:
        return True  # Not running

    try:
        # Send SIGTERM
        os.kill(pid, signal.SIGTERM)

        # Wait for process to exit
        for _ in range(30):  # 3 seconds max
            time.sleep(0.1)
            try:
                os.kill(pid, 0)
            except OSError:
                # Process exited
                break
        else:
            # Force kill
            os.kill(pid, signal.SIGKILL)

        # Clean up
        if os.path.exists(socket_path):
            os.unlink(socket_path)

        pid_file = _get_pid_file()
        if os.path.exists(pid_file):
            os.unlink(pid_file)

        return True

    except OSError:
        return False


def ensure_daemon_running(socket_path: Optional[str] = None) -> bool:
    """Ensure the daemon is running, starting it if necessary.

    Args:
        socket_path: Path to the Unix socket

    Returns:
        True if daemon is running

    Raises:
        RuntimeError: If daemon fails to start
    """
    socket_path = socket_path or DEFAULT_SOCKET_PATH

    if is_daemon_running(socket_path):
        return True

    if start_daemon(socket_path):
        return True

    raise RuntimeError("Failed to start bash_daemon")


def _get_pid_file() -> str:
    """Get the path to the daemon's PID file."""
    runtime_dir = os.environ.get("XDG_RUNTIME_DIR", f"/run/user/{os.getuid()}")
    if not os.path.exists(runtime_dir):
        runtime_dir = f"/tmp/aish-{os.getuid()}"
    return os.path.join(runtime_dir, "aish", "bashd.pid")


# CLI entry point
def main():
    """Command-line interface for daemon management."""
    import argparse

    parser = argparse.ArgumentParser(description="Bash daemon management")
    parser.add_argument(
        "command",
        choices=["start", "stop", "status", "restart"],
        help="Command to execute",
    )
    parser.add_argument(
        "--socket",
        "-s",
        default=DEFAULT_SOCKET_PATH,
        help="Unix socket path",
    )
    parser.add_argument(
        "--foreground",
        "-f",
        action="store_true",
        help="Run in foreground",
    )
    parser.add_argument(
        "--debug",
        "-d",
        action="store_true",
        help="Enable debug logging",
    )

    args = parser.parse_args()

    if args.command == "start":
        if is_daemon_running(args.socket):
            print("Daemon already running")
            return 0
        if start_daemon(args.socket, args.foreground, args.debug):
            print("Daemon started")
            return 0
        else:
            print("Failed to start daemon", file=sys.stderr)
            return 1

    elif args.command == "stop":
        if stop_daemon(args.socket):
            print("Daemon stopped")
            return 0
        else:
            print("Failed to stop daemon", file=sys.stderr)
            return 1

    elif args.command == "status":
        if is_daemon_running(args.socket):
            pid = get_daemon_pid()
            print(f"Daemon running (PID: {pid})")
            return 0
        else:
            print("Daemon not running")
            return 1

    elif args.command == "restart":
        stop_daemon(args.socket)
        if start_daemon(args.socket, foreground=args.foreground, debug=args.debug):
            print("Daemon restarted")
            return 0
        else:
            print("Failed to restart daemon", file=sys.stderr)
            return 1

    return 0


if __name__ == "__main__":
    sys.exit(main())
