"""Simple Unix Socket server for bash daemon.

Based on pyxtermjs approach: pty.fork() + background polling thread.
Enhanced with fd 3 status channel for cwd and exit code tracking.

Key features:
- pty.fork() for full terminal support
- Background thread for output polling (like pyxtermjs)
- Simple JSON protocol over Unix Socket
- Multiple sessions support
- fd 3 status channel for cwd/exit tracking
"""

from __future__ import annotations

import json
import logging
import os
import pty
import select
import signal
import socket
import struct
import subprocess
import sys
import termios
import tempfile
import threading
import time
import uuid
from pathlib import Path
from typing import Dict, Optional

# Default socket path
RUNTIME_DIR = os.environ.get("XDG_RUNTIME_DIR", f"/run/user/{os.getuid()}")
if not os.path.exists(RUNTIME_DIR):
    RUNTIME_DIR = f"/tmp/aish-{os.getuid()}"
    os.makedirs(RUNTIME_DIR, mode=0o700, exist_ok=True)
DEFAULT_SOCKET_PATH = os.path.join(RUNTIME_DIR, "aish", "bashd.sock")


def set_winsize(fd: int, row: int, col: int, xpix: int = 0, ypix: int = 0) -> None:
    """Set terminal window size."""
    winsize = struct.pack("HHHH", row, col, xpix, ypix)
    fcntl.ioctl(fd, termios.TIOCSWINSZ, winsize)


# Need fcntl for set_winsize
import fcntl


# Bash initialization script for fd 3 status channel
_BASH_INIT_SCRIPT = '''
# aish bash_daemon initialization with status tracking

# Disable bracketed paste mode
set enable-bracketed-paste off 2>/dev/null || true

# Save last exit code globally
__aish_last_exit=0

# Function to report status via OSC sequence
__aish_report_status() {
    printf "\\x1b]aish-status:%s:%d\\x07" "$PWD" "$__aish_last_exit"
}

# Use PROMPT_COMMAND which runs AFTER each command
# This is the key - it runs with $? set to the command's exit code
__aish_prompt_hook() {
    __aish_last_exit=$?
    __aish_report_status
}

PROMPT_COMMAND="__aish_prompt_hook"
export PROMPT_COMMAND

# Empty prompt (aish has its own prompt)
PS1=
export PS1
'''


class BashSession:
    """A bash session with PTY and fd 3 status channel."""

    def __init__(
        self,
        master_fd: int,
        pid: int,
        rows: int = 24,
        cols: int = 80,
        cwd: str = "",
        status_file: str = "",
    ):
        self.master_fd = master_fd
        self.pid = pid
        self.rows = rows
        self.cols = cols
        self.cwd = cwd or os.getcwd()
        self.status_file = status_file
        self.active = True
        self._last_exit_code = 0
        self._output_buffer = bytearray()
        self._command_seq = 0  # Command sequence number for status updates

    @classmethod
    def create(cls, rows: int = 24, cols: int = 80, cwd: Optional[str] = None) -> "BashSession":
        """Create a new bash session using pty.fork()."""
        cwd = cwd or os.getcwd()

        # Create temp directory and init script
        status_dir = Path(tempfile.gettempdir()) / f"aish-{os.getuid()}"
        status_dir.mkdir(mode=0o700, exist_ok=True)

        # Write init script that will be sourced
        init_script = str(status_dir / f"bash_init_{uuid.uuid4().hex[:8]}.sh")
        with open(init_script, "w") as f:
            f.write(_BASH_INIT_SCRIPT)
        os.chmod(init_script, 0o600)

        child_pid, master_fd = pty.fork()

        if child_pid == 0:
            # Child process: run bash
            os.chdir(cwd)

            # Set up environment
            env = dict(os.environ)
            env["TERM"] = "xterm-256color"
            env["PS1"] = ""  # Empty prompt
            env["INPUTRC"] = "/dev/null"  # Disable inputrc

            # Set PROMPT_COMMAND directly in environment
            # This is more reliable than sourcing a script
            env["PROMPT_COMMAND"] = (
                "__aish_last_exit=$?; "
                "printf '\\x1b]aish-status:%s:%d\\x07' \"$PWD\" \"$__aish_last_exit\""
            )

            os.execvpe(
                "/bin/bash",
                ["/bin/bash", "--norc", "--noprofile", "-i"],
                env,
            )
            os._exit(1)
        else:
            # Parent process
            # Set non-blocking
            flags = fcntl.fcntl(master_fd, fcntl.F_GETFL)
            fcntl.fcntl(master_fd, fcntl.F_SETFL, flags | os.O_NONBLOCK)

            # Set window size
            set_winsize(master_fd, rows, cols)

            # Wait for bash to start
            session = cls(master_fd, child_pid, rows, cols, cwd, "")
            session._wait_for_ready()

            # Clean up init script (not used anymore)
            try:
                os.unlink(init_script)
            except OSError:
                pass

            return session

    def _clear_output(self) -> None:
        """Clear any pending output from the PTY."""
        try:
            while True:
                ready, _, _ = select.select([self.master_fd], [], [], 0.01)
                if not ready:
                    break
                try:
                    os.read(self.master_fd, 65536)
                except OSError:
                    break
        except Exception:
            pass

    def _wait_for_ready(self, timeout: float = 0.5) -> None:
        """Wait for bash to be ready."""
        start = time.time()
        while time.time() - start < timeout:
            ready, _, _ = select.select([self.master_fd], [], [], 0.05)
            if ready:
                try:
                    os.read(self.master_fd, 4096)
                except OSError:
                    break
            time.sleep(0.01)

    def read_output(self, timeout: float = 0.01, max_bytes: int = 1024 * 20) -> Optional[bytes]:
        """Read output from PTY (non-blocking with select).

        Also parses fd 3 status markers embedded in output.
        """
        if not self.active:
            return None

        try:
            ready, _, _ = select.select([self.master_fd], [], [], timeout)
            if ready:
                data = os.read(self.master_fd, max_bytes)
                if not data:
                    self.active = False
                    return None

                # Parse for status markers: \033[aish-status:/path/to/dir:0\007
                output, status_updates = self._parse_status_markers(data)

                # Apply status updates
                for status_cwd, status_exit in status_updates:
                    if status_cwd:
                        self.cwd = status_cwd
                    if status_exit is not None:
                        self._last_exit_code = status_exit

                return output if output else None
        except OSError:
            self.active = False
        return None

    def _parse_status_markers(self, data: bytes) -> tuple[Optional[bytes], list[tuple[Optional[str], Optional[int]]]]:
        """Parse fd 3 status markers from output.

        Status markers are embedded as OSC sequences: \x1b]aish-status:/path:0\x07
        Returns (cleaned_output, [(cwd, exit_code), ...])
        """
        output_parts = []
        status_updates = []

        # Find status markers: \x1b]aish-status:...\x07
        marker = b"\x1b]aish-status:"
        end_marker = b"\x07"
        pos = 0

        while pos < len(data):
            marker_start = data.find(marker, pos)
            if marker_start == -1:
                output_parts.append(data[pos:])
                break

            # Output before marker
            output_parts.append(data[pos:marker_start])

            # Find end of marker (BEL character)
            marker_end = data.find(end_marker, marker_start)
            if marker_end == -1:
                # Incomplete marker, treat as normal output
                output_parts.append(data[marker_start:])
                break

            # Parse status: /path/to/dir:0
            status_str = data[marker_start + len(marker):marker_end].decode("utf-8", errors="ignore")
            parts = status_str.split(":")
            if len(parts) >= 2:
                status_cwd = parts[0] if parts[0] else None
                try:
                    status_exit = int(parts[1]) if parts[1].lstrip('-').isdigit() else 0
                except ValueError:
                    status_exit = 0
                status_updates.append((status_cwd, status_exit))
                # Increment command sequence when OSC status is received (command completed)
                self._command_seq += 1

            pos = marker_end + 1

        cleaned = b"".join(output_parts) if output_parts else None
        return (cleaned, status_updates)

    def write_input(self, data: bytes) -> int:
        """Write input to PTY."""
        if not self.active:
            return 0
        return os.write(self.master_fd, data)

    def resize(self, rows: int, cols: int) -> None:
        """Resize terminal."""
        if self.active:
            self.rows = rows
            self.cols = cols
            set_winsize(self.master_fd, rows, cols)

    def close(self) -> None:
        """Close the session."""
        self.active = False
        try:
            os.close(self.master_fd)
        except OSError:
            pass
        try:
            os.kill(self.pid, signal.SIGTERM)
            time.sleep(0.1)
            os.waitpid(self.pid, 0)
        except (ProcessLookupError, ChildProcessError):
            pass

    def is_alive(self) -> bool:
        """Check if bash process is still running."""
        if not self.active:
            return False
        try:
            pid, _ = os.waitpid(self.pid, os.WNOHANG)
            return pid == 0
        except ChildProcessError:
            self.active = False
            return False

    @property
    def last_exit_code(self) -> int:
        """Get last command exit code."""
        return self._last_exit_code


class SimpleBashDaemon:
    """Simple bash daemon using pyxtermjs-style background polling."""

    def __init__(self, socket_path: Optional[str] = None):
        self.socket_path = socket_path or DEFAULT_SOCKET_PATH
        self.sessions: Dict[str, BashSession] = {}
        self.clients: Dict[str, socket.socket] = {}  # session_id -> client socket
        self.running = False
        self.server_socket: Optional[socket.socket] = None
        self._lock = threading.Lock()

    def start(self) -> None:
        """Start the daemon server."""
        # Ensure socket directory exists
        socket_dir = os.path.dirname(self.socket_path)
        if socket_dir:
            Path(socket_dir).mkdir(parents=True, exist_ok=True)
            try:
                os.chmod(socket_dir, 0o700)
            except OSError:
                pass

        # Remove stale socket
        if os.path.exists(self.socket_path):
            try:
                os.unlink(self.socket_path)
            except OSError:
                pass

        # Create Unix socket
        self.server_socket = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        self.server_socket.bind(self.socket_path)
        self.server_socket.listen(10)
        os.chmod(self.socket_path, 0o600)

        self.running = True
        logging.info(f"[bashd] Listening on {self.socket_path}")

        # Start accept thread
        accept_thread = threading.Thread(target=self._accept_loop, daemon=True)
        accept_thread.start()

    def stop(self) -> None:
        """Stop the daemon."""
        self.running = False

        # Close all sessions
        for session in self.sessions.values():
            session.close()
        self.sessions.clear()

        # Close all clients
        for client in self.clients.values():
            try:
                client.close()
            except Exception:
                pass
        self.clients.clear()

        # Close server socket
        if self.server_socket:
            self.server_socket.close()

        # Remove socket file
        if os.path.exists(self.socket_path):
            try:
                os.unlink(self.socket_path)
            except OSError:
                pass

        logging.info("[bashd] Stopped")

    def _accept_loop(self) -> None:
        """Accept new client connections."""
        self.server_socket.settimeout(1.0)

        while self.running:
            try:
                client_sock, _ = self.server_socket.accept()
                client_sock.setblocking(True)

                # Handle client in new thread
                thread = threading.Thread(
                    target=self._handle_client,
                    args=(client_sock,),
                    daemon=True
                )
                thread.start()

            except socket.timeout:
                continue
            except Exception as e:
                if self.running:
                    logging.error(f"[bashd] Accept error: {e}")

    def _handle_client(self, client_sock: socket.socket) -> None:
        """Handle a client connection."""
        session_id = None
        output_thread = None

        try:
            while self.running:
                # Read message
                msg = self._read_message(client_sock)
                if msg is None:
                    break

                msg_type = msg.get("type")

                if msg_type == "session_create":
                    # Create new session
                    data = msg.get("data", {})
                    rows = data.get("rows", 24)
                    cols = data.get("cols", 80)
                    cwd = data.get("cwd")

                    session = BashSession.create(rows=rows, cols=cols, cwd=cwd)
                    session_id = str(uuid.uuid4())

                    with self._lock:
                        self.sessions[session_id] = session
                        self.clients[session_id] = client_sock

                    # Start output forwarding thread (pyxtermjs style)
                    output_thread = threading.Thread(
                        target=self._output_forwarder,
                        args=(session_id,),
                        daemon=True
                    )
                    output_thread.start()

                    # Send confirmation
                    self._write_message(client_sock, {
                        "type": "session_created",
                        "session_id": session_id,
                        "data": {"cwd": cwd or os.getcwd()}
                    })

                elif msg_type == "input":
                    # Forward input to PTY
                    sid = msg.get("session_id", session_id)
                    if sid and sid in self.sessions:
                        input_hex = msg.get("data", {}).get("bytes", "")
                        if input_hex:
                            input_bytes = bytes.fromhex(input_hex)
                            self.sessions[sid].write_input(input_bytes)

                elif msg_type == "resize":
                    # Resize terminal
                    sid = msg.get("session_id", session_id)
                    if sid and sid in self.sessions:
                        data = msg.get("data", {})
                        self.sessions[sid].resize(
                            data.get("rows", 24),
                            data.get("cols", 80)
                        )

                elif msg_type == "session_close":
                    sid = msg.get("session_id", session_id)
                    if sid and sid in self.sessions:
                        self.sessions[sid].close()
                        with self._lock:
                            del self.sessions[sid]
                            if sid in self.clients:
                                del self.clients[sid]
                    break

                elif msg_type == "ping":
                    self._write_message(client_sock, {"type": "pong"})

        except (ConnectionError, OSError) as e:
            logging.debug(f"[bashd] Client error: {e}")
        finally:
            # Cleanup session
            if session_id and session_id in self.sessions:
                self.sessions[session_id].close()
                with self._lock:
                    self.sessions.pop(session_id, None)
                    self.clients.pop(session_id, None)

            try:
                client_sock.close()
            except Exception:
                pass

    def _output_forwarder(self, session_id: str) -> None:
        """Background thread to forward PTY output and status to client.

        This is the pyxtermjs approach: simple polling loop in a thread.
        Also sends status updates (cwd, exit code, command_seq) to client.
        """
        last_cwd = None
        last_exit = None
        last_seq = -1  # Start with -1 so initial status (seq=0) is sent

        while self.running and session_id in self.sessions:
            session = self.sessions.get(session_id)
            if not session or not session.active:
                break

            # Read output (non-blocking with select)
            output = session.read_output(timeout=0.01)

            if output:
                # Send output to client
                client = self.clients.get(session_id)
                if client:
                    try:
                        self._write_message(client, {
                            "type": "output",
                            "session_id": session_id,
                            "data": {"bytes": output.hex()}
                        })
                    except (ConnectionError, OSError):
                        break

            # Check for status changes and send them (even if no output)
            # Use command_seq to detect when a new command has completed
            if session.cwd != last_cwd or session.last_exit_code != last_exit or session._command_seq != last_seq:
                last_cwd = session.cwd
                last_exit = session.last_exit_code
                last_seq = session._command_seq
                client = self.clients.get(session_id)
                if client:
                    try:
                        self._write_message(client, {
                            "type": "status",
                            "session_id": session_id,
                            "data": {
                                "cwd": last_cwd,
                                "exit": last_exit,
                                "seq": last_seq
                            }
                        })
                    except (ConnectionError, OSError):
                        break

            if not output and not session.is_alive():
                # Session terminated
                break

        # Notify client of session end
        client = self.clients.get(session_id)
        if client:
            try:
                self._write_message(client, {
                    "type": "session_closed",
                    "session_id": session_id
                })
            except Exception:
                pass

    def _read_message(self, sock: socket.socket) -> Optional[dict]:
        """Read a JSON message with 4-byte length prefix."""
        try:
            length_data = sock.recv(4)
            if len(length_data) < 4:
                return None

            length = struct.unpack(">I", length_data)[0]
            if length == 0 or length > 1024 * 1024:
                return None

            data = b""
            while len(data) < length:
                chunk = sock.recv(length - len(data))
                if not chunk:
                    return None
                data += chunk

            return json.loads(data.decode("utf-8"))

        except (ConnectionError, json.JSONDecodeError, struct.error):
            return None

    def _write_message(self, sock: socket.socket, msg: dict) -> None:
        """Write a JSON message with 4-byte length prefix."""
        with self._lock:  # Protect against concurrent socket writes
            data = json.dumps(msg, separators=(",", ":")).encode("utf-8")
            length = struct.pack(">I", len(data))
            sock.sendall(length + data)


def main():
    """Main entry point."""
    import argparse

    parser = argparse.ArgumentParser(description="Simple bash daemon")
    parser.add_argument("--socket", "-s", default=DEFAULT_SOCKET_PATH)
    parser.add_argument("--debug", "-d", action="store_true")
    args = parser.parse_args()

    logging.basicConfig(
        format="%(asctime)s [bashd] %(message)s",
        level=logging.DEBUG if args.debug else logging.INFO,
    )

    daemon = SimpleBashDaemon(args.socket)

    def signal_handler(sig, frame):
        logging.info("\n[bashd] Shutting down...")
        daemon.stop()
        sys.exit(0)

    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)

    daemon.start()

    # Keep main thread alive
    while daemon.running:
        time.sleep(1)


if __name__ == "__main__":
    main()
