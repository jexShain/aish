"""Bash daemon for persistent shell sessions with PTY support.

This module provides a local bash session management system based on
pyxtermjs approach: pty.fork() + background polling thread.

Features:
- Unix sockets for local IPC (fast, no web dependencies)
- Multiple clients with independent sessions
- Full bash feature support (aliases, functions, history)
- Interactive commands (vim, less, ssh, etc.)

Architecture:
    aish (clients) → Unix Socket → bash_daemon → PTY + bash sessions

Usage:
    from aish.bash_daemon import BashClient, start_daemon, is_daemon_running

    # Start daemon (usually automatic)
    start_daemon()

    # Create client and connect
    client = BashClient()
    client.connect()

    # Send user input
    client.send(b"ls -la\\n")

    # Receive output (with callback)
    client.subscribe(lambda data: print(data.decode(), end=''))
    time.sleep(1)

    # Or polling mode
    output = client.recv(timeout=1.0)
    print(output.decode())

    client.close()
"""

from .client import SimpleBashClient as BashClient
from .daemon import (
    start_daemon,
    stop_daemon,
    is_daemon_running,
    ensure_daemon_running,
)
from .integration import (
    BashDaemonIntegration,
    create_bash_integration,
    setup_signal_handlers,
)
from .server import SimpleBashDaemon as BashDaemonServer
from .server import BashSession

__all__ = [
    # Client
    "BashClient",
    # Server
    "BashDaemonServer",
    # Session
    "BashSession",
    # Daemon management
    "start_daemon",
    "stop_daemon",
    "is_daemon_running",
    "ensure_daemon_running",
    # Integration
    "BashDaemonIntegration",
    "create_bash_integration",
    "setup_signal_handlers",
]
