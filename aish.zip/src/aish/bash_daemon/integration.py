"""Integration layer for bash_daemon with aish shell.

This module provides the glue between aish's existing shell infrastructure
and the bash_daemon backend. Based on pyxtermjs-style polling approach.

Key responsibilities:
- Manage the bash_daemon lifecycle (start on demand)
- Route user input (AI vs bash vs aish internal)
- Handle Ctrl+C signal routing
"""

from __future__ import annotations

import os
import signal
import sys
from typing import TYPE_CHECKING, Callable, Dict, Optional

from .client import SimpleBashClient as BashClient
from .daemon import ensure_daemon_running, is_daemon_running, start_daemon

if TYPE_CHECKING:
    pass


class BashDaemonIntegration:
    """Integration layer connecting aish to bash_daemon.

    This class:
    1. Starts the daemon on first use
    2. Manages the client connection
    3. Routes signals (Ctrl+C) correctly
    """

    def __init__(
        self,
        on_output: Optional[Callable[[bytes], None]] = None,
        on_status: Optional[Callable[[Dict], None]] = None,
    ):
        """Initialize the integration layer.

        Args:
            on_output: Callback for terminal output (for display)
            on_status: Callback for status updates (cwd, exit code)
        """
        self._client: Optional[BashClient] = None
        self._on_output = on_output
        self._on_status = on_status
        self._running = False
        self._current_cwd = os.getcwd()

        # Signal handling state
        self._bash_busy = False
        self._ai_thinking = False
        self._ask_user_active = False
        self._command_sent = False  # Track if we sent a command
        self._initial_status_received = False  # Skip first status update
        self._last_seq = -1  # Track command sequence number

    def start(self, cwd: Optional[str] = None) -> bool:
        """Start the integration (connect to daemon).

        Args:
            cwd: Initial working directory

        Returns:
            True if started successfully
        """
        if self._client is not None:
            return True

        try:
            # Ensure daemon is running
            ensure_daemon_running()

            # Create and connect client
            self._client = BashClient()
            self._client.connect(cwd=cwd or os.getcwd())
            self._current_cwd = cwd or os.getcwd()

            # Subscribe to output
            if self._on_output:
                self._client.subscribe(self._handle_output)

            # Subscribe to status updates (cwd, exit code)
            self._client.subscribe_status(self._handle_status)

            self._running = True
            return True

        except Exception as e:
            print(f"[bash_daemon] Failed to start: {e}", file=sys.stderr)
            self._client = None
            return False

    def _handle_status(self, cwd: str, exit_code: int, seq: int = -1) -> None:
        """Handle status updates from bash."""
        # Update cwd
        if cwd:
            self._current_cwd = cwd

        # Only update bash_busy if we sent a command (skip initial status)
        # Use sequence number to detect command completion
        if self._command_sent and seq > self._last_seq:
            self._bash_busy = False
            self._command_sent = False
            self._last_seq = seq
        elif not self._command_sent:
            self._initial_status_received = True
            self._last_seq = seq

        # Notify callback
        if self._on_status:
            self._on_status({"cwd": cwd, "exit": exit_code})

    def _handle_output(self, data: bytes) -> None:
        """Handle output from bash."""
        # Check for prompt to update busy state
        self._check_prompt(data)

        # Forward to callback
        if self._on_output:
            self._on_output(data)

    def stop(self) -> None:
        """Stop the integration (disconnect from daemon)."""
        self._running = False

        if self._client:
            self._client.close()
            self._client = None

    def send(self, data: bytes) -> int:
        """Send user input to bash.

        Args:
            data: Raw bytes (can be text, control codes, etc.)

        Returns:
            Number of bytes sent
        """
        if not self._client:
            raise RuntimeError("Not connected to bash_daemon")

        # Mark that we're sending input (will wait for status update)
        if b'\n' in data:
            self._command_sent = True
        self._bash_busy = True
        return self._client.send(data)

    def send_text(self, text: str) -> int:
        """Send text input to bash.

        Args:
            text: Text string to send

        Returns:
            Number of bytes sent
        """
        return self.send(text.encode("utf-8"))

    def send_command(self, command: str) -> int:
        """Send a command (adds newline).

        Args:
            command: Command to execute

        Returns:
            Number of bytes sent
        """
        return self.send_text(command + "\n")

    def send_signal(self, sig: int) -> None:
        """Send a signal to the bash process.

        This routes signals correctly:
        - If bash is busy: send to bash (Ctrl+C = \\x03)
        - If AI is thinking: cancel AI task
        - If ask_user is active: cancel prompt

        Args:
            sig: Signal number (e.g., signal.SIGINT)
        """
        if self._ai_thinking:
            # AI should handle this separately
            pass
        elif self._ask_user_active:
            # Cancel ask_user prompt
            self._ask_user_active = False
            if self._on_output:
                self._on_output(b"\n[cancelled]\n")
        elif self._bash_busy and self._client:
            # Forward to bash as Ctrl+C
            self._client.send(b"\x03")
            self._bash_busy = False

    def resize(self, rows: int, cols: int) -> None:
        """Resize the terminal.

        Args:
            rows: New number of rows
            cols: New number of columns
        """
        if self._client:
            self._client.resize(rows, cols)

    @property
    def cwd(self) -> str:
        """Get current working directory."""
        return self._current_cwd

    @property
    def is_connected(self) -> bool:
        """Check if connected to daemon."""
        return self._client is not None and self._client.is_connected

    @property
    def is_bash_busy(self) -> bool:
        """Check if bash is executing a command."""
        return self._bash_busy

    def set_ai_thinking(self, thinking: bool) -> None:
        """Set AI thinking state.

        Called by aish when AI starts/stops processing.

        Args:
            thinking: True if AI is thinking, False otherwise
        """
        self._ai_thinking = thinking

    def set_ask_user_active(self, active: bool) -> None:
        """Set ask_user prompt state.

        Called by aish when showing y/N or arrow-key prompts.

        Args:
            active: True if ask_user prompt is showing
        """
        self._ask_user_active = active

    def _check_prompt(self, output: bytes) -> None:
        """Check output for prompt patterns.

        When we detect a prompt, bash is no longer busy.

        Args:
            output: Recent output bytes
        """
        # Simple heuristic: look for common prompt patterns
        try:
            text = output.decode("utf-8", errors="ignore")
            # Look for $ or # at end of line (common prompts)
            if text.rstrip().endswith(("$", "#", ">")):
                self._bash_busy = False
        except Exception:
            pass

    def __enter__(self) -> "BashDaemonIntegration":
        self.start()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        self.stop()


# ---------------------------------------------------------------------------
# Convenience functions
# ---------------------------------------------------------------------------

def create_bash_integration(
    shell,
) -> BashDaemonIntegration:
    """Create a bash_daemon integration for aish shell.

    This is the main entry point for aish to use bash_daemon.

    Args:
        shell: The AIShell instance

    Returns:
        Configured BashDaemonIntegration instance
    """
    def on_output(data: bytes) -> None:
        """Handle bash output."""
        # Write directly to shell's stdout
        if hasattr(shell, "_write_output"):
            shell._write_output(data)
        else:
            sys.stdout.buffer.write(data)
            sys.stdout.buffer.flush()

    def on_status(status: Dict) -> None:
        """Handle status updates."""
        # Update shell's cwd tracking
        if status.get("cwd") and hasattr(shell, "current_cwd"):
            shell.current_cwd = status["cwd"]

    return BashDaemonIntegration(on_output=on_output, on_status=on_status)


# ---------------------------------------------------------------------------
# Signal handling setup
# ---------------------------------------------------------------------------

def setup_signal_handlers(shell) -> None:
    """Set up signal handlers for aish.

    This ensures Ctrl+C is routed correctly based on current state.

    Args:
        shell: The AIShell instance
    """
    original_handler = signal.getsignal(signal.SIGINT)

    def handle_sigint(sig, frame):
        """Handle SIGINT (Ctrl+C)."""
        # Check current state and route appropriately
        if hasattr(shell, "_bash_integration"):
            integration = shell._bash_integration

            if integration._ai_thinking:
                # Cancel AI task
                if hasattr(shell, "_cancel_ai_task"):
                    shell._cancel_ai_task()
                return

            if integration._ask_user_active:
                # Cancel ask_user
                integration.send_signal(sig)
                return

            if integration._bash_busy:
                # Forward to bash
                integration.send_signal(sig)
                return

        # Default: call original handler or do nothing
        if callable(original_handler):
            original_handler(sig, frame)
        else:
            # Just print newline
            print()

    signal.signal(signal.SIGINT, handle_sigint)
